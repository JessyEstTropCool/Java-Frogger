#!/bin/bash 

javac Frogger.java
java Frogger
