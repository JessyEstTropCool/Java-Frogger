public class Tronc extends Entity 
{
    public Tronc(int posX, int posY, int width, int height)
    {
        super(posX, posY, width, height);
    }

    @Override
    public String getType() { return "Tronc"; }
}
