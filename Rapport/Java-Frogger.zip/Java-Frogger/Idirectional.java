//Interface dictant des constantes de direction
public interface Idirectional 
{
    public final int LEFT = 0, UP = 1, RIGHT = 2, DOWN = 3, STOP = -1;
}
